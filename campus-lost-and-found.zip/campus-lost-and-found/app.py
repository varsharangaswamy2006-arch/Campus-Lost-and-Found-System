import os
import sqlite3
import uuid
from datetime import date

from flask import (Flask, flash, g, redirect, render_template, request,
                   send_from_directory, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "lostfound.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
CATEGORIES = ["Electronics", "Books & Notes", "ID / Cards", "Keys", "Bags",
              "Clothing", "Accessories", "Other"]

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-me-in-production")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# ---------- database ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config.get("DATABASE", DATABASE))
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(app.config.get("DATABASE", DATABASE))
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            kind TEXT NOT NULL CHECK (kind IN ('lost', 'found')),
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            location TEXT NOT NULL,
            event_date TEXT NOT NULL,
            contact TEXT NOT NULL,
            image TEXT,
            status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """
    )
    # default admin (change the password after first login!)
    exists = db.execute("SELECT 1 FROM users WHERE email = ?", ("admin@campus.edu",)).fetchone()
    if not exists:
        db.execute(
            "INSERT INTO users (name, email, password_hash, is_admin) VALUES (?, ?, ?, 1)",
            ("Admin", "admin@campus.edu", generate_password_hash("admin123")),
        )
    db.commit()
    db.close()


# ---------- helpers ----------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def current_user():
    uid = session.get("user_id")
    if uid is None:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


@app.context_processor
def inject_user():
    return {"current_user": current_user()}


def login_required(view):
    from functools import wraps

    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            flash("Please log in first.", "warning")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


# ---------- routes ----------
@app.route("/")
def index():
    q = request.args.get("q", "").strip()
    kind = request.args.get("kind", "")
    category = request.args.get("category", "")
    show = request.args.get("show", "open")

    sql = "SELECT items.*, users.name AS poster FROM items JOIN users ON users.id = items.user_id WHERE 1=1"
    params = []
    if q:
        sql += " AND (title LIKE ? OR description LIKE ? OR location LIKE ?)"
        params += [f"%{q}%"] * 3
    if kind in ("lost", "found"):
        sql += " AND kind = ?"
        params.append(kind)
    if category in CATEGORIES:
        sql += " AND category = ?"
        params.append(category)
    if show != "all":
        sql += " AND status = 'open'"
    sql += " ORDER BY created_at DESC, id DESC"
    items = get_db().execute(sql, params).fetchall()
    return render_template("index.html", items=items, categories=CATEGORIES,
                           q=q, kind=kind, category=category, show=show)


@app.route("/item/<int:item_id>")
def item_detail(item_id):
    item = get_db().execute(
        "SELECT items.*, users.name AS poster FROM items JOIN users ON users.id = items.user_id WHERE items.id = ?",
        (item_id,),
    ).fetchone()
    if item is None:
        return render_template("404.html"), 404
    return render_template("detail.html", item=item)


@app.route("/report", methods=["GET", "POST"])
@login_required
def report():
    if request.method == "POST":
        f = request.form
        required = ["kind", "title", "description", "category", "location", "event_date", "contact"]
        if any(not f.get(k, "").strip() for k in required) or f["kind"] not in ("lost", "found") \
                or f["category"] not in CATEGORIES:
            flash("Please fill in all required fields.", "danger")
            return render_template("report.html", categories=CATEGORIES, form=f, today=date.today().isoformat())

        image_name = None
        file = request.files.get("image")
        if file and file.filename:
            if not allowed_file(file.filename):
                flash("Image must be png, jpg, jpeg, gif or webp.", "danger")
                return render_template("report.html", categories=CATEGORIES, form=f, today=date.today().isoformat())
            image_name = f"{uuid.uuid4().hex}_{secure_filename(file.filename)}"
            file.save(os.path.join(app.config["UPLOAD_FOLDER"], image_name))

        db = get_db()
        cur = db.execute(
            """INSERT INTO items (user_id, kind, title, description, category, location,
                                  event_date, contact, image)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (session["user_id"], f["kind"], f["title"].strip(), f["description"].strip(),
             f["category"], f["location"].strip(), f["event_date"], f["contact"].strip(), image_name),
        )
        db.commit()
        flash("Your report has been posted.", "success")
        return redirect(url_for("item_detail", item_id=cur.lastrowid))
    return render_template("report.html", categories=CATEGORIES, form={}, today=date.today().isoformat())


@app.route("/item/<int:item_id>/resolve", methods=["POST"])
@login_required
def resolve(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
    user = current_user()
    if item is None:
        return render_template("404.html"), 404
    if item["user_id"] != user["id"] and not user["is_admin"]:
        flash("You can only update your own reports.", "danger")
        return redirect(url_for("item_detail", item_id=item_id))
    new_status = "open" if item["status"] == "resolved" else "resolved"
    db.execute("UPDATE items SET status = ? WHERE id = ?", (new_status, item_id))
    db.commit()
    flash(f"Marked as {new_status}.", "success")
    return redirect(url_for("item_detail", item_id=item_id))


@app.route("/item/<int:item_id>/delete", methods=["POST"])
@login_required
def delete(item_id):
    db = get_db()
    item = db.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()
    user = current_user()
    if item is None:
        return render_template("404.html"), 404
    if item["user_id"] != user["id"] and not user["is_admin"]:
        flash("You can only delete your own reports.", "danger")
        return redirect(url_for("item_detail", item_id=item_id))
    if item["image"]:
        try:
            os.remove(os.path.join(app.config["UPLOAD_FOLDER"], item["image"]))
        except OSError:
            pass
    db.execute("DELETE FROM items WHERE id = ?", (item_id,))
    db.commit()
    flash("Report deleted.", "success")
    return redirect(url_for("index"))


@app.route("/my-reports")
@login_required
def my_reports():
    items = get_db().execute(
        "SELECT * FROM items WHERE user_id = ? ORDER BY created_at DESC, id DESC", (session["user_id"],)
    ).fetchall()
    return render_template("my_reports.html", items=items)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not name or not email or len(password) < 6:
            flash("Name, email and a password of at least 6 characters are required.", "danger")
            return render_template("register.html")
        db = get_db()
        if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
            flash("That email is already registered.", "danger")
            return render_template("register.html")
        cur = db.execute("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
                         (name, email, generate_password_hash(password)))
        db.commit()
        session["user_id"] = cur.lastrowid
        flash("Welcome! Your account has been created.", "success")
        return redirect(url_for("index"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Invalid email or password.", "danger")
            return render_template("login.html")
        session["user_id"] = user["id"]
        flash(f"Welcome back, {user['name']}!", "success")
        nxt = request.args.get("next", "")
        return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("index"))
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))


@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)


@app.errorhandler(404)
def not_found(_e):
    return render_template("404.html"), 404


init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
